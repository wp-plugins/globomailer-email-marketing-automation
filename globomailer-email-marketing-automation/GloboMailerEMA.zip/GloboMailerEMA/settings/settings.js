function _gmema_redirect()
{
	window.location = "admin.php?page=gmema-settings";
}

function _gmema_help()
{
	window.open("http://www.archirayan.com");
}